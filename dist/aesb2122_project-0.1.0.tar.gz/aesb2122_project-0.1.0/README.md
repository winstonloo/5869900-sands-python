This repository includes files to create signals, modify signals and plot signals.

The signals available are:
Sine, Square, triangular, sawtooth and unit step.

Modifications possible to original signals:
Time shift, time scale, amplitude scale, added wave, multiplied wave

the plots will be plotted next to eachother with the original on the left and the modified version on the right.

in the run file, the variables are given.

#Variables
f = Frequency, s_t = start time,  e_t = end time, a = amplitude, s_t = start_time 
